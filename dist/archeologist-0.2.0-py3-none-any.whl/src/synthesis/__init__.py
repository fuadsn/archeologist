from .narrative import NarrativeSynthesizer
